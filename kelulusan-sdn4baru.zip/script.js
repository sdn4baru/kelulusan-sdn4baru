
const waktuBuka = new Date('2025-06-02T10:00:00+07:00');
const sekarang = new Date();
if (sekarang < waktuBuka) {
  document.getElementById('formSection').style.display = 'none';
  document.getElementById('notyet').style.display = 'block';
}

const dataSiswa = {
  "0121294946": ["AHMAD ABILQUBES", "22 AGUSTUS 2012", "LULUS"],
  "0121915812": ["ANAYA SAFIRA", "28 AGUSTUS 2012", "LULUS"],
  "0121738410": ["ANGGI MAULANA", "28 APRIL 2012", "LULUS"]
  // Tambahkan sisanya sesuai kebutuhan
};

function cekKelulusan() {
  const nisn = document.getElementById('nisn').value.trim();
  const result = document.getElementById('result');
  if (dataSiswa[nisn]) {
    const [nama, tgl, status] = dataSiswa[nisn];
    result.innerHTML = `
      <p>NISN: <strong>${nisn}</strong></p>
      <p>Nama: <strong>${nama}</strong></p>
      <p>Tanggal Lahir: <strong>${tgl}</strong></p>
      <p>Hasil: <strong style="color:green">${status}</strong></p>
    `;
  } else {
    result.innerHTML = `<p style="color:red">Data tidak ditemukan.</p>`;
  }
}

function adminLogin() {
  const user = document.getElementById('adminUser').value.trim();
  const pass = document.getElementById('adminPass').value.trim();
  const msg = document.getElementById('adminMessage');
  if (user === 'sdn4baru' && pass === 'barupat4pbun') {
    msg.innerHTML = '<p style="color:green">Login berhasil! (Fitur admin akan ditambahkan)</p>';
  } else {
    msg.innerHTML = '<p style="color:red">Username atau password salah</p>';
  }
}
